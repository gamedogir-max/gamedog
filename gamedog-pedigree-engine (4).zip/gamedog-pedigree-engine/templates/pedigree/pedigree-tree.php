<?php
/**
 * 5-Generation Pedigree Tree Template - Compact Engine
 * 
 * @var array $tree
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'gdpe_render_tree_cell_item' ) ) {
    function gdpe_render_tree_cell_item( $node, $rowspan, $gen ) {
        $palette = [ '#52b788', '#9d4edd', '#2a9d8f', '#e76f51', '#c77dff', '#b5838d', '#3a86ff' ];

        if ( empty( $node ) || empty( $node['id'] ) ) {
            return '<td rowspan="' . $rowspan . '" class="gd-ped-cell gd-ped-empty gd-gen-' . $gen . '"><span>Unknown</span></td>';
        }

        $id        = (int) $node['id'];
        $title     = ! empty( $node['title'] ) ? $node['title'] : get_the_title( $id );
        $link      = get_permalink( $id );
        $thumb     = get_the_post_thumbnail_url( $id, 'thumbnail' );
        $titles    = get_post_meta( $id, 'dog_titles', true );
        $color_dot = get_post_meta( $id, 'pedigree_color_dot', true ) ?: $palette[ ( $id % count( $palette ) ) ];

        $out = '<td rowspan="' . $rowspan . '" class="gd-ped-cell gd-gen-' . $gen . '">';
        $out .= '<div class="gd-ped-content">';

        if ( ! empty( $titles ) ) {
            $out .= '<div class="gd-ped-titles">' . esc_html( $titles ) . '</div>';
        }

        $out .= '<div class="gd-ped-title-wrap">';
        $out .= '<a href="' . esc_url( $link ) . '" class="gd-ped-name">' . esc_html( $title ) . '</a>';
        if ( ! empty( $thumb ) ) {
            $out .= ' <span class="gd-ped-cam" title="Photo available">📷</span>';
        }
        $out .= '</div>';

        if ( ( $gen === 1 || $gen === 2 ) && ! empty( $thumb ) ) {
            $out .= '<div class="gd-ped-thumb"><a href="' . esc_url( $link ) . '"><img src="' . esc_url( $thumb ) . '" alt="' . esc_attr( $title ) . '"></a></div>';
        }

        if ( $gen >= 3 ) {
            $out .= '<div class="gd-ped-dot" style="background-color: ' . esc_attr( $color_dot ) . ';"></div>';
        }

        $out .= '</div>';
        $out .= '</td>';

        return $out;
    }
}

$rows = array_fill( 0, 32, '' );

$populateBranch = function( $node, $start_row, $total_rows, $gen ) use ( &$populateBranch, &$rows ) {
    if ( $gen > 5 ) return;

    $rows[$start_row] .= gdpe_render_tree_cell_item( $node, $total_rows, $gen );

    $half = (int) ($total_rows / 2);
    $sire = $node['sire'] ?? null;
    $dam  = $node['dam'] ?? null;

    $populateBranch( $sire, $start_row, $half, $gen + 1 );
    $populateBranch( $dam, $start_row + $half, $half, $gen + 1 );
};

// شاخه پدر (ردیف‌های ۰ تا ۱۵) و شاخه مادر (ردیف‌های ۱۶ تا ۳۱)
$sireBranch = $tree['sire'] ?? null;
$damBranch  = $tree['dam'] ?? null;

$populateBranch( $sireBranch, 0, 16, 1 );
$populateBranch( $damBranch, 16, 16, 1 );
?>

<div class="gd-pedigree-wrapper" dir="ltr">
    <div class="gd-ped-header">Pedigree</div>
    <div class="gd-ped-table-responsive">
        <table class="gd-ped-table">
            <tbody>
                <?php foreach ( $rows as $row_html ) : ?>
                    <tr><?php echo $row_html; ?></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>