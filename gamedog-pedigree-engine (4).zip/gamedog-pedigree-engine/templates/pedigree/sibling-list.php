<?php
/**
 * Sibling List Template - Matching Legacy Snippet Design
 * 
 * @var array $siblings Array of Dog Entity objects
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="gd-siblings-wrapper" dir="ltr">
    <?php if ( empty( $siblings ) ) : ?>
        <div class="gd-sib-empty">No dogs found in database.</div>
    <?php else : ?>
        <div class="gd-sib-grid">
            <?php foreach ( $siblings as $dog ) : 
                $dog_id   = $dog->getId()->getValue();
                $title    = $dog->getName();
                $link     = get_permalink( $dog_id );
                $thumb    = get_the_post_thumbnail_url( $dog_id, 'thumbnail' ) ?: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" fill="%23eee"/></svg>';
                $sex      = $dog->getSex() ? strtolower( $dog->getSex() ) : '';
                $sex_ico  = ( $sex === 'male' || $sex === 'Male' ) ? '♂' : ( ( $sex === 'female' || $sex === 'Female' ) ? '♀' : '' );
            ?>
                <a href="<?php echo esc_url( $link ); ?>" class="gd-sib-item">
                    <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $title ); ?>">
                    <div class="gd-sib-meta">
                        <span class="gd-sib-title">
                            <?php echo esc_html( $title ); ?>
                            <?php if ( $sex_ico ) : ?>
                                <span class="gd-sib-sex"><?php echo esc_html( $sex_ico ); ?></span>
                            <?php endif; ?>
                        </span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>