<?php

declare(strict_types=1);

namespace GDPE\Presentation\Renderer;

use GDPE\Domain\Entity\Dog;

final class SiblingListRenderer
{
    /**
     * @param array<int, Dog> $dogs
     */
    public function render(array $dogs, string $heading, string $emptyMessage): string
    {
        $currentId = get_the_ID();

        // حذف سگ جاری و موارد نامعتبر
        $validDogs = array_filter($dogs, function (Dog $dog) use ($currentId) {
            $id = $dog->getId()->getValue();
            return $id > 0 && $id !== $currentId;
        });

        ob_start();
        ?>
        <div class="gd-siblings-wrapper" dir="ltr">
            <?php if (empty($validDogs)) : ?>
                <div class="gd-sib-empty"><?php echo esc_html($emptyMessage); ?></div>
            <?php else : ?>
                <div class="gd-sib-grid">
                    <?php foreach ($validDogs as $dog) :
                        $dogId   = $dog->getId()->getValue();
                        $title   = $dog->getName();
                        $link    = get_permalink($dogId);
                        $thumb   = get_the_post_thumbnail_url($dogId, 'thumbnail') ?: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" fill="%23eee"/></svg>';
                        $sex     = $dog->getSex() ? strtolower($dog->getSex()) : '';
                        $sexIco  = ($sex === 'male' || $sex === 'm') ? '♂' : (($sex === 'female' || $sex === 'f') ? '♀' : '');
                    ?>
                        <a href="<?php echo esc_url($link); ?>" class="gd-sib-item">
                            <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($title); ?>">
                            <div class="gd-sib-meta">
                                <span class="gd-sib-title">
                                    <?php echo esc_html($title); ?>
                                    <?php if ($sexIco) : ?>
                                        <span class="gd-sib-sex"><?php echo esc_html($sexIco); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public function renderNotice(string $message): string
    {
        return sprintf(
            '<div class="gd-siblings-wrapper" dir="ltr"><div class="gd-sib-empty">%s</div></div>',
            esc_html($message)
        );
    }
}