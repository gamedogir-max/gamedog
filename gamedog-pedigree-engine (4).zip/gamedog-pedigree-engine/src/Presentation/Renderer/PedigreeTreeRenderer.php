<?php

declare(strict_types=1);

namespace GDPE\Presentation\Renderer;

use GDPE\Domain\Model\PedigreeTree;
use GDPE\Domain\ValueObject\PedigreeNode;

final class PedigreeTreeRenderer
{
    public function __construct(
        private readonly string $templateDirectory,
    ) {
    }

    public function render(PedigreeTree $tree): string
    {
        $templatePath = $this->templateDirectory . '/pedigree-tree.php';

        if (! file_exists($templatePath)) {
            return '';
        }

        // فراخوانی متد دقیق دامنه: rootNode()
        $root = $tree->rootNode();

        $treeArray = [
            'sire' => $this->nodeToArray($root->father()),
            'dam'  => $this->nodeToArray($root->mother()),
        ];

        ob_start();
        $tree = $treeArray;
        include $templatePath;

        return (string) ob_get_clean();
    }

    private function nodeToArray(?PedigreeNode $node): ?array
    {
        if ($node === null) {
            return null;
        }

        $dog = $node->dog();

        return [
            'id'    => $dog->getId()->getValue(),
            'title' => $dog->getName(),
            'sex'   => $dog->getSex(),
            'sire'  => $this->nodeToArray($node->father()),
            'dam'   => $this->nodeToArray($node->mother()),
        ];
    }

    public function renderNotice(string $message): string
    {
        return sprintf('<div class="gd-ped-empty" style="text-align:center; padding:15px; color:#888;">%s</div>', esc_html($message));
    }
}