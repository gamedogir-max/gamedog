<?php

declare(strict_types=1);

namespace GDPE\Presentation\ServiceProvider;

use GDPE\Application\UseCase\BuildPedigreeTreeUseCase;
use GDPE\Application\UseCase\FindFullSiblingsUseCase;
use GDPE\Application\UseCase\FindSameDamUseCase;
use GDPE\Application\UseCase\FindSameSireUseCase;
use GDPE\Infrastructure\Container\ServiceContainer;
use GDPE\Presentation\Elementor\PedigreeAssetRegistrar;
use GDPE\Presentation\Elementor\PedigreeCategoryRegistrar;
use GDPE\Presentation\Elementor\PedigreeWidgetRegistrar;
use GDPE\Presentation\Renderer\PedigreeTreeRenderer;
use GDPE\Presentation\Renderer\SiblingListRenderer;

/**
 * Registers every Presentation-layer (Elementor) binding.
 *
 * Kept separate from the Infrastructure provider so the Elementor
 * integration is a self-contained, opt-in slice of the composition root.
 * The template directory, CSS URL, and version are supplied by the caller
 * (the plugin's main file) so no Presentation class hardcodes a filesystem
 * path or reaches for a WordPress function.
 */
final class ElementorServiceProvider
{
    public static function register(
        ServiceContainer $container,
        string $templateDirectory,
        string $cssUrl,
        string $version,
    ): void {
        $container->bind(
            PedigreeTreeRenderer::class,
            static fn (): PedigreeTreeRenderer => new PedigreeTreeRenderer(
                $templateDirectory,
            ),
        );

        $container->bind(
            PedigreeCategoryRegistrar::class,
            static fn (): PedigreeCategoryRegistrar => new PedigreeCategoryRegistrar(),
        );

        $container->bind(
            PedigreeAssetRegistrar::class,
            static fn (): PedigreeAssetRegistrar => new PedigreeAssetRegistrar(
                $cssUrl,
                $version,
            ),
        );

        $container->bind(
            SiblingListRenderer::class,
            static fn (): SiblingListRenderer => new SiblingListRenderer(
                $templateDirectory,
            ),
        );

        $container->bind(
            PedigreeWidgetRegistrar::class,
            static fn (ServiceContainer $c): PedigreeWidgetRegistrar => new PedigreeWidgetRegistrar(
                $c->get(BuildPedigreeTreeUseCase::class),
                $c->get(PedigreeTreeRenderer::class),
                $c->get(FindFullSiblingsUseCase::class),
                $c->get(FindSameSireUseCase::class),
                $c->get(FindSameDamUseCase::class),
                $c->get(SiblingListRenderer::class),
            ),
        );
    }
}
