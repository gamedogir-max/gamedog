<?php

declare(strict_types=1);

namespace GDPE\Presentation\Shortcodes;

use Elementor\Plugin;
use GDPE\Application\UseCase\FindFullSiblingsUseCase;
use GDPE\Application\UseCase\FindSameDamUseCase;
use GDPE\Application\UseCase\FindSameSireUseCase;
use GDPE\Domain\Entity\Dog;
use GDPE\Domain\ValueObject\DogId;
use Throwable;

final class SiblingsUnifiedShortcode
{
    private static ?FindFullSiblingsUseCase $fullSiblingsUseCase = null;
    private static ?FindSameSireUseCase $sameSireUseCase = null;
    private static ?FindSameDamUseCase $sameDamUseCase = null;

    public static function bootstrap(
        FindFullSiblingsUseCase $fullSiblingsUseCase,
        FindSameSireUseCase $sameSireUseCase,
        FindSameDamUseCase $sameDamUseCase,
    ): void {
        self::$fullSiblingsUseCase = $fullSiblingsUseCase;
        self::$sameSireUseCase     = $sameSireUseCase;
        self::$sameDamUseCase      = $sameDamUseCase;
        add_shortcode('gamedog_siblings_box', [self::class, 'render']);
    }

    public static function render(): string
    {
        $currentId = (int) get_the_ID();
        if ($currentId <= 0 && did_action('elementor/loaded') && Plugin::$instance->documents->get_current()) {
            $currentId = (int) Plugin::$instance->documents->get_current()->get_main_id();
        }

        if ($currentId <= 0) {
            return '';
        }

        $fullSiblings = [];
        $sameSire = [];
        $sameDam = [];

        try {
            $dogId = new DogId($currentId);

            if (self::$fullSiblingsUseCase !== null) {
                $fullSiblings = self::$fullSiblingsUseCase->execute($dogId);
            }
            if (self::$sameSireUseCase !== null) {
                $sameSire = self::$sameSireUseCase->execute($dogId);
            }
            if (self::$sameDamUseCase !== null) {
                $sameDam = self::$sameDamUseCase->execute($dogId);
            }
        } catch (Throwable $e) {
            // Silence
        }

        $filterDogs = function (array $dogs) use ($currentId): array {
            $clean = [];
            $seen = [];
            foreach ($dogs as $dog) {
                if (! ($dog instanceof Dog)) continue;
                $id = $dog->getId()->getValue();
                if ($id > 0 && $id !== $currentId && !isset($seen[$id]) && get_post_status($id) === 'publish') {
                    $seen[$id] = true;
                    $clean[] = $dog;
                }
            }
            return $clean;
        };

        $fullSiblings = $filterDogs($fullSiblings);
        $sameSire     = $filterDogs($sameSire);
        $sameDam      = $filterDogs($sameDam);

        $renderList = function (array $dogs): string {
            if (empty($dogs)) {
                return '<div class="gd-sib-empty">No dogs found in database.</div>';
            }

            $out = '<div class="gd-sib-grid">';
            foreach ($dogs as $dog) {
                $id      = $dog->getId()->getValue();
                $title   = $dog->getName();
                $link    = get_permalink($id);
                $thumb   = get_the_post_thumbnail_url($id, 'thumbnail') ?: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" fill="%23eee"/></svg>';
                $sex     = $dog->getSex() ? strtolower($dog->getSex()) : '';
                $sexIco  = ($sex === 'male' || $sex === 'm') ? '♂' : (($sex === 'female' || $sex === 'f') ? '♀' : '');
                $sexCls  = ($sex === 'male' || $sex === 'm') ? 'is-male' : (($sex === 'female' || $sex === 'f') ? 'is-female' : '');

                $out .= '<a href="' . esc_url($link) . '" class="gd-sib-item">';
                $out .= '<img src="' . esc_url($thumb) . '" alt="' . esc_attr($title) . '">';
                $out .= '<div class="gd-sib-meta">';
                $out .= '<span class="gd-sib-title">' . esc_html($title);
                if ($sexIco) {
                    $out .= ' <span class="gd-sib-sex ' . esc_attr($sexCls) . '">' . esc_html($sexIco) . '</span>';
                }
                $out .= '</span></div>';
                $out .= '</a>';
            }
            $out .= '</div>';
            return $out;
        };

        ob_start();
        ?>
        <div class="gd-siblings-wrapper" dir="ltr">
            <div class="gd-sib-tabs-nav">
                <button type="button" class="gd-snav-btn gd-snav-active" data-tab="full-sib">Full Siblings (<?php echo count($fullSiblings); ?>)</button>
                <button type="button" class="gd-snav-btn" data-tab="same-sire">Same Sire (<?php echo count($sameSire); ?>)</button>
                <button type="button" class="gd-snav-btn" data-tab="same-dam">Same Dam (<?php echo count($sameDam); ?>)</button>
            </div>

            <div class="gd-sib-tabs-content">
                <div class="gd-stab-pane gd-stab-active" id="gd-tab-full-sib">
                    <?php echo $renderList($fullSiblings); ?>
                </div>
                <div class="gd-stab-pane" id="gd-tab-same-sire">
                    <?php echo $renderList($sameSire); ?>
                </div>
                <div class="gd-stab-pane" id="gd-tab-same-dam">
                    <?php echo $renderList($sameDam); ?>
                </div>
            </div>
        </div>

        <script>
        (function() {
            document.addEventListener('click', function(e) {
                var btn = e.target.closest('.gd-siblings-wrapper .gd-snav-btn');
                if (!btn) return;
                e.preventDefault();
                var wrap = btn.closest('.gd-siblings-wrapper');
                if (!wrap) return;

                wrap.querySelectorAll('.gd-snav-btn').forEach(function(b) { b.classList.remove('gd-snav-active'); });
                wrap.querySelectorAll('.gd-stab-pane').forEach(function(p) { p.classList.remove('gd-stab-active'); });

                btn.classList.add('gd-snav-active');
                var targetId = 'gd-tab-' + btn.getAttribute('data-tab');
                var targetPane = wrap.querySelector('#' + targetId);
                if (targetPane) targetPane.classList.add('gd-stab-active');
            });
        })();
        </script>
        <?php
        return (string) ob_get_clean();
    }
}