<?php

declare(strict_types=1);

namespace GDPE\Presentation\Shortcodes;

use GDPE\Application\UseCase\BuildPedigreeTreeUseCase;
use GDPE\Domain\ValueObject\DogId;
use GDPE\Domain\ValueObject\Generation;
use GDPE\Presentation\Renderer\PedigreeTreeRenderer;
use Throwable;

final class PedigreeTreeShortcode
{
    private static ?BuildPedigreeTreeUseCase $useCase = null;
    private static ?PedigreeTreeRenderer $renderer = null;

    public static function bootstrap(
        BuildPedigreeTreeUseCase $useCase,
        PedigreeTreeRenderer $renderer,
    ): void {
        self::$useCase = $useCase;
        self::$renderer = $renderer;
        add_shortcode('gamedog_pedigree_tree', [self::class, 'render']);
    }

    public static function render(): string
    {
        $currentId = (int) get_the_ID();
        if ($currentId <= 0 || self::$useCase === null || self::$renderer === null) {
            return '';
        }

        try {
            $tree = self::$useCase->execute(new DogId($currentId), Generation::fromInt(5));
            return self::$renderer->render($tree);
        } catch (Throwable $e) {
            return '';
        }
    }
}